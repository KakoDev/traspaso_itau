//HEADERS
export const SPAN_ID = 'x-span-id';
export const PARENT_ID = 'x-parent-id';
export const CORRELATION_ID = 'x-correlation-id';
export const TRANSACTION_ID = 'x-transaction-id';
export const CONSUMER_ID = 'x-consumer-id';
export const CHANNEL_ID = 'x-channel-id';