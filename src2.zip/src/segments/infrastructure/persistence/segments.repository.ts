import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Segments } from '../../domain/models/segments.model';
import { SegmentsRepository } from '../../domain/repositories/segments.repository.interface';
import { CreateSegmentDTO } from '../../application/dtos/create-segments.dto';
import { UpdateSegmentDTO } from '../../application/dtos/update-segments.dto';

@Injectable()
export class SegmentsRepositoryImpl implements SegmentsRepository {
    constructor(
        @InjectRepository(Segments)
        private readonly repository: Repository<Segments>
    ) { }

    async findAll(): Promise<Segments[]> {
        return this.repository.find();
    }

    async findById(id: number): Promise<Segments | undefined> {
        return this.repository.findOne({ where: { id } });
    }

    async createSegment(segment: CreateSegmentDTO): Promise<Segments> {
        return this.repository.save(segment);
    }

    async updateSegment(id: number, segment: UpdateSegmentDTO): Promise<Segments | undefined> {
        await this.repository.update(id, segment);
        return this.findById(id);
    }

    async deleteSegment(id: number): Promise<boolean> {
        await this.repository.delete(id);
        return true;
    }
}