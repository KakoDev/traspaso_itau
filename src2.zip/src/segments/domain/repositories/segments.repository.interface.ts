import { Segments } from '../models/Segments.model';

export interface SegmentsRepository {
    findAll(): Promise<Segments[]>;
    findById(id: number): Promise<Segments | undefined>;
    createSegment(segment: Segments): Promise<Segments>;
    updateSegment(id: number, segment: Segments): Promise<Segments | undefined>;
    deleteSegment(id: number): Promise<boolean>;
}