import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { SegmentsService } from '@app/services/segments.service';
import { SegmentsUseCase } from '@app/useCase/segments.usecase';
import { Segments } from '../domain/models/segments.model';
import { SegmentsRepositoryImpl } from '../infrastructure/persistence/segments.repository';
import { SegmentsController } from './controllers/segments.controller';

@Module({
    imports: [
        TypeOrmModule.forFeature([Segments])
    ],
    controllers: [SegmentsController],
    providers: [
        SegmentsRepositoryImpl,
        SegmentsService,
        SegmentsUseCase
    ]
})

export class SegmentModule { }