import { Body, Controller, Delete, Get, HttpStatus, Param, Post, Put, UseFilters } from '@nestjs/common';
import { ApiNotFoundResponse, ApiOkResponse, ApiTags, ApiUnauthorizedResponse } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';

import { HttpExceptionFilter } from '@shared/interceptor/http.exception.filter';
import { SegmentsUseCase } from '@app/useCase/segments.usecase';
import { Segments } from '../../domain/models/segments.model';
import { CreateSegmentDTO } from '../../application/dtos/create-segments.dto';
import { ResponseSegmentsDTO } from '../../application/dtos/response-segments.dto';

@ApiTags('Segments')
@UseFilters(HttpExceptionFilter)
@Controller('segments')
export class SegmentsController {
    constructor(private readonly segmentUseCase: SegmentsUseCase) { }

    @Get()
    @ApiOkResponse({ description: 'Obtener todos los segmentos' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async findAll(): Promise<ResponseSegmentsDTO[]> {
        const data = this.segmentUseCase.getAllSegments();
        return plainToInstance(ResponseSegmentsDTO, (await data).map((item) => plainToInstance(ResponseSegmentsDTO, item)));        
    }

    @Get(':id')
    @ApiOkResponse({ description: 'Obtener segumento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async findById(@Param('id') id: number): Promise<ResponseSegmentsDTO | undefined> {
        return plainToInstance(ResponseSegmentsDTO, this.segmentUseCase.getSegmentById(id));
    }

    @Post()
    @ApiOkResponse({ description: 'Creación de Segmento' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async create(@Body() segment: CreateSegmentDTO): Promise<ResponseSegmentsDTO> {
        return this.segmentUseCase.createSegment(segment);
    }

    @Put(':id')
    @ApiOkResponse({ description: 'Actualización de segmento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async update(@Param('id') id: number, @Body() segment: Segments): Promise<ResponseSegmentsDTO | undefined> {
        return this.segmentUseCase.updateSegment(id, segment);
    }

    @Delete(':id')
    @ApiOkResponse({ description: 'Eliminación de segumento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async delete(@Param('id') id: number): Promise<boolean> {
        return this.segmentUseCase.deleteSegment(id);
    }
}
