import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';

import { Segments } from '../../domain/models/segments.model';
import { SegmentsRepository } from '../../domain/repositories/segments.repository.interface';
import { CreateSegmentDTO } from '../dtos/create-segments.dto';
import { UpdateSegmentDTO } from '../dtos/update-segments.dto';

@Injectable()
export class SegmentsService {
    constructor(
        @InjectRepository(Segments)
        private readonly segmentRepository: SegmentsRepository,
    ) { }

    async findAll(): Promise<Segments[]> {
        return this.segmentRepository.findAll()
    }

    async findById(id: number): Promise<Segments | undefined> {
        console.log('aca me caigo?')
        Object.keys(this.segmentRepository).forEach( key => {
            console.log(key);
        });
        return this.segmentRepository.findById( id );
    }

    async create(segment: CreateSegmentDTO): Promise<Segments> {
        const screate : Segments = {
            id: 0,
            segment: segment.segment,
            createdAt: new Date(),
            createdBy: segment.createdBy,
            updatedAt: null,
            updatedBy: null,
        }
        return this.segmentRepository.createSegment(screate);
    }

    async update(id: number, segment: UpdateSegmentDTO): Promise<Segments | undefined> {
        const toUpdate = await this.findById(id);
        const supdate : Segments = {
            id: toUpdate.id,
            segment: segment.segment,
            createdAt: toUpdate.createdAt,
            createdBy: toUpdate.createdBy,
            updatedAt: new Date(),
            updatedBy: null,
        }        
        await this.segmentRepository.updateSegment(id, supdate);
        return this.findById(id);
    }

    async delete(id: number): Promise<boolean> {
        await this.segmentRepository.deleteSegment(id);
        return true;
    }
}
