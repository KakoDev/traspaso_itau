import { Injectable } from '@nestjs/common';

import { ResponseSegmentsDTO } from '@app/dtos/response-segments.dto';
import { CreateSegmentDTO } from '../dtos/create-segments.dto';
import { UpdateSegmentDTO } from '../dtos/update-segments.dto';
import { SegmentsService } from '../services/segments.service';

@Injectable()
export class SegmentsUseCase {
    constructor(private readonly segmentRepository: SegmentsService) { }

    async getAllSegments(): Promise<ResponseSegmentsDTO[]> {
        return this.segmentRepository.findAll();
    }

    async getSegmentById(id: number): Promise<ResponseSegmentsDTO | undefined> {
        return this.segmentRepository.findById(id);
    }

    async createSegment(segment: CreateSegmentDTO): Promise<ResponseSegmentsDTO> {
        return this.segmentRepository.create(segment);
    }

    async updateSegment(id: number, segment: UpdateSegmentDTO): Promise<ResponseSegmentsDTO | undefined> {
        return this.segmentRepository.update(id, segment);
    }

    async deleteSegment(id: number): Promise<boolean> {
        return this.segmentRepository.delete(id);
    }
}
