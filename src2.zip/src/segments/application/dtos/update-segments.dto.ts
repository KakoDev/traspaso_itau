export interface UpdateSegmentDTO {
    segment: string;
    updatedBy: string;
}
