export class ResponseSegmentsDTO {
    id: number;
    segment: string;
}