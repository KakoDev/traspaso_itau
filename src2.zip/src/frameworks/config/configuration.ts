export default () => ({
    port: parseInt(process.env.PORT, 10) || 3010,
    database_connection_string: process.env.DATABASE_URL,
  });