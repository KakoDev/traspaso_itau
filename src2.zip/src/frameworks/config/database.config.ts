import { DynamicModule } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { join } from 'path';
import { writeFileSync } from 'fs';

async function createOrmConfigFile(dbConfig: any) {
    const path = join(__dirname, '../../');
    writeFileSync(path + 'ormconfig.json', JSON.stringify(dbConfig, null, 2));
}

export const DatabaseProvider: DynamicModule = TypeOrmModule.forRootAsync({
    inject: [ConfigService],
    async useFactory(config: ConfigService) : Promise<any> {
        const isDevelopmentEnv = config.get('NODE_ENV') !== 'production';

        const dbConfig = {
            type: 'postgres',
            host: config.get('DB_HOST') || "192.168.100.63",
            port: +config.get('DB_PORT') || 5432,
            username: config.get('DB_USER') || "postgres",
            password: config.get('DB_PASSWORD') || "Test01",
            database: config.get('DB_NAME') || "tesopro",
            autoLoadEntities: true,
            synchronize: isDevelopmentEnv,
            migrations: ['dist/database/migrations/*.js'],
            entities: ['dist/**/*.entity.js'],
            cli: {
                migrationsDir: 'src/database/migrations',
            },
            logging: 'all',
        };

        if (isDevelopmentEnv) {
            createOrmConfigFile(dbConfig);
        }

        return dbConfig;
    },
});
