import { Exclude } from 'class-transformer';
import {
  Column,
  Entity,
  Index,
  PrimaryGeneratedColumn
} from "typeorm";

@Index("product_families_pkey", ["id"], { unique: true })
@Index("product_families_product_family_key", ["productFamily"], {
  unique: true,
})
@Entity("product_families", { schema: "ingfin" })
export class ProductFamilies {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "product_family",
    unique: true,
    length: 50,
  })
  productFamily: string;

  @Column("character varying", {
    name: "created_by",
    nullable: true,
    length: 50,
  })
  @Exclude()
  createdBy: string | null;

  @Column("timestamp without time zone", { name: "created_at", default: () => 'CURRENT_TIMESTAMP' })
  @Exclude()
  createdAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  @Exclude()
  updatedBy: string | null;

  @Column("timestamp without time zone", { name: "updated_at", nullable: true })
  @Exclude()
  updatedAt: Date | null;
}
