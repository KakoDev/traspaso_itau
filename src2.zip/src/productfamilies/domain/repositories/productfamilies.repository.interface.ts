import { ProductFamilies } from '../models/ProductFamilies';

export interface SegmentsRepository {
    findAll(): Promise<ProductFamilies[]>;
    findById(id: number): Promise<ProductFamilies | undefined>;
    create(segment: ProductFamilies): Promise<ProductFamilies>;
    update(id: number, segment: ProductFamilies): Promise<ProductFamilies | undefined>;
    delete(id: number): Promise<void>;
}