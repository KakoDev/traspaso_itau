import { ProductFamilies } from '../domain/models/ProductFamilies';

export const ProductFamiliesMock: ProductFamilies = {
    id: 1,
    productFamily: 'Mock Segment',
    createdBy: 'Mock User',
    createdAt: new Date(),
    updatedBy: 'Mock User',
    updatedAt: new Date(),
};

export const ProductFamiliesArrayMock: ProductFamilies[] = [
    {
        id: 1,
        productFamily: 'Mock productFamily 1',
        createdBy: 'Mock User',
        createdAt: new Date(),
        updatedBy: 'Mock User',
        updatedAt: new Date(),
    },
    {
        id: 2,
        productFamily: 'Mock productFamily 2',
        createdBy: 'Mock User',
        createdAt: new Date(),
        updatedBy: 'Mock User',
        updatedAt: new Date(),
    },
];
