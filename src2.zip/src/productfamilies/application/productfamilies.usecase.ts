import { Injectable } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';

import { ProductFamilies } from '../domain/models/ProductFamilies';
import { ProductFamiliesRepositoryImpl } from '../infrastructure/persistence/productfamilies.repository';

@Injectable()
export class ProductFamiliesUseCase {
    constructor(private readonly pfRepository: ProductFamiliesRepositoryImpl) { }

    async getAllSegments(): Promise<ProductFamilies[]> {
        const data = this.pfRepository.findAll();
        return plainToInstance(ProductFamilies, (await data).map((item) => plainToInstance(ProductFamilies, item)));
    }

    async getSegmentById(id: number): Promise<ProductFamilies | undefined> {
        return plainToInstance(ProductFamilies, this.pfRepository.findById(id));
    }

    // async createSegment(segment: CreateProductFamiliesDTO): Promise<ProductFamilies> {
    //     return this.pfRepository.create(segment);
    // }

    // async updateSegment(id: number, segment: ProductFamilies): Promise<ProductFamilies | undefined> {
    //     return this.pfRepository.update(id, segment);
    // }

    async deleteSegment(id: number): Promise<void> {
        return this.pfRepository.delete(id);
    }
}
