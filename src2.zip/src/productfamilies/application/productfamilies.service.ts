import { Injectable } from '@nestjs/common';

import { ProductFamilies } from '../domain/models/ProductFamilies';
import { ProductFamiliesUseCase } from './productfamilies.usecase';
import { CreateProductFamiliesDTO } from '../interfaces/dtos/create-productfamilies.dtos';
import { UpdateProductFamiliesDTO } from '../interfaces/dtos/update-productfamilies.dtos';

@Injectable()
export class ProductFamiliesService {
    constructor(
        private readonly familyproductsUseCase: ProductFamiliesUseCase,
    ) { }

    async findAll(): Promise<ProductFamilies[]> {
        return this.familyproductsUseCase.getAllSegments();
    }

    async findById(id: number): Promise<ProductFamilies | undefined> {
        return this.familyproductsUseCase.getSegmentById(id);
    }

    // async create(segment: CreateProductFamiliesDTO): Promise<ProductFamilies> {
    //     return this.familyproductsUseCase.createSegment(segment);
    // }

    // async update(id: number, segment: UpdateProductFamiliesDTO): Promise<ProductFamilies | undefined> {
    //     return this.familyproductsUseCase.updateSegment(id, segment);
    // }

    async delete(id: number): Promise<void> {
        return this.familyproductsUseCase.deleteSegment(id);
    }
}
