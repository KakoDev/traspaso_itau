import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { ProductFamilies } from '../../domain/models/ProductFamilies';
import { SegmentsRepository } from '../../domain/repositories/productfamilies.repository.interface';

@Injectable()
export class ProductFamiliesRepositoryImpl implements SegmentsRepository {
    constructor( @InjectRepository(ProductFamilies) private readonly repository: Repository<ProductFamilies>) { }

    async findAll(): Promise<ProductFamilies[]> {
        return this.repository.find();
    }

    async findById(id: number): Promise<ProductFamilies | undefined> {
        return this.repository.findOne({ where: { id } });
    }

    async create(segment: ProductFamilies): Promise<ProductFamilies> {
        return this.repository.save(segment);
    }

    async update(id: number, segment: ProductFamilies): Promise<ProductFamilies | undefined> {
        await this.repository.update(id, segment);
        return this.findById(id);
    }

    async delete(id: number): Promise<void> {
        await this.repository.delete(id);
    }
}