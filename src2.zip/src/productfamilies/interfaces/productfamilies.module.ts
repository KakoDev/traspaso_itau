import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// import { ProductFamiliesService } from 'src/familyproducts/application/productfamilies.service';
//import { ProductFamiliesUseCase } from 'src/familyproducts/application/productfamilies.usecase';
import { ProductFamilies } from '../domain/models/ProductFamilies';
import { ProductFamiliesRepositoryImpl } from '../infrastructure/persistence/productfamilies.repository';
import { ProductFamiliesController } from './controllers/productfamilies.controller';

@Module({
    imports: [
        TypeOrmModule.forFeature([ProductFamilies])
    ],
    controllers: [ProductFamiliesController],
    providers: [
        ProductFamiliesRepositoryImpl
        // ProductFamiliesService,
        // ProductFamiliesUseCase]
    ]
})

export class SegmentModule { }