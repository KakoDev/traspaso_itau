export interface UpdateProductFamiliesDTO {
    segment: string;
    updatedBy: string;
}
