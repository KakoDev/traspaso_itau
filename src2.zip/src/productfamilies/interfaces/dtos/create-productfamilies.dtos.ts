export interface CreateProductFamiliesDTO {
    segment: string;
    createdBy: string;
}
