// interfaces/controllers/segment.controller.ts

import { Body, Controller, Delete, Get, HttpStatus, Param, Post, Put, UseFilters } from '@nestjs/common';
import { ApiNotFoundResponse, ApiOkResponse, ApiTags, ApiUnauthorizedResponse } from '@nestjs/swagger';

import { HttpExceptionFilter } from '@shared/interceptor/http.exception.filter';
import { ProductFamiliesService } from '../../application/productfamilies.service';
import { ProductFamilies } from '../../domain/models/ProductFamilies';

@ApiTags('ProductFamilies')
@UseFilters(HttpExceptionFilter)
@Controller('productfamilies')
export class ProductFamiliesController {
    constructor(private readonly pfService: ProductFamiliesService) { }

    @Get()
    @ApiOkResponse({ description: 'Obtener todos los segmentos' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async findAll(): Promise<ProductFamilies[]> {
        return this.pfService.findAll();
    }

    @Get(':id')
    @ApiOkResponse({ description: 'Obtener segumento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async findById(@Param('id') id: number): Promise<ProductFamilies | undefined> {
        return this.pfService.findById(id);
    }

    @Post()
    // @ApiOkResponse({ description: 'Creación de Segmento' })
    // @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    // @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    // async create(@Body() segment: CreateSegmentDTO): Promise<ProductFamilies> {
    //     return this.pfService.create(segment);
    // }

    // @Put(':id')
    // @ApiOkResponse({ description: 'Actualización de segmento según ID' })
    // @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    // @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    // async update(@Param('id') id: number, @Body() pf: ProductFamilies): Promise<ProductFamilies | undefined> {
    //     return this.pfService.update(id, pf);
    // }

    @Delete(':id')
    @ApiOkResponse({ description: 'Eliminación de segumento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async delete(@Param('id') id: number): Promise<void> {
        return this.pfService.delete(id);
    }
}
