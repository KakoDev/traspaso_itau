import { Injectable } from '@nestjs/common';

import { Segments } from '@domain/models/segments.model';
import { SegmentsRepository } from '@domain/repositories/segments.repository.interface';
import { SegmentsRepositoryImpl } from '@infrastructure/persistence/segments/segments.repository';
import { CreateSegmentDTO } from '@interfaces/dtos/segments/create-segments.dtos';
import { UpdateSegmentDTO } from '@interfaces/dtos/segments/update-segments.dtos';
import { ResponseSegmentDTO } from '@interfaces/dtos/segments/response-segments.dtos';

@Injectable()
export class SegmentsUseCase {
    constructor(private readonly segmentRepository: SegmentsRepositoryImpl) { }

    async getAllSegments(): Promise<Segments[]> {
        return this.segmentRepository.findAll();
    }

    async getSegmentById(id: number): Promise<ResponseSegmentDTO | undefined> {
        const data = await this.segmentRepository.findById(id);
        console.log(data);
        return data;
    }

    async createSegment(segment: CreateSegmentDTO): Promise<ResponseSegmentDTO> {
        return this.segmentRepository.create(segment);
    }

    async updateSegment(id: number, segment: UpdateSegmentDTO): Promise<ResponseSegmentDTO | undefined> {
        return this.segmentRepository.update(id, segment);
    }

    async deleteSegment(id: number): Promise<void> {
        return this.segmentRepository.delete(id);
    }
}
