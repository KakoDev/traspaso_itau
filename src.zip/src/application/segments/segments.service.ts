import { Injectable } from '@nestjs/common';

import { SegmentsUseCase } from '@app/segments/segments.usecase';
import { CreateSegmentDTO } from '@interfaces/dtos/segments/create-segments.dtos';
import { ResponseSegmentDTO } from '@interfaces/dtos/segments/response-segments.dtos';
import { UpdateSegmentDTO } from '@interfaces/dtos/segments/update-segments.dtos';

@Injectable()
export class SegmentsService {
    constructor(
        private readonly segmentUseCase: SegmentsUseCase,
    ) { }

    async findAll(): Promise<ResponseSegmentDTO[]> {
        return this.segmentUseCase.getAllSegments();
    }

    async findById(id: number): Promise<ResponseSegmentDTO | undefined> {
        return this.segmentUseCase.getSegmentById(id);
    }

    async create(segment: CreateSegmentDTO): Promise<ResponseSegmentDTO> {
        return this.segmentUseCase.createSegment(segment);
    }

    async update(id: number, segment: UpdateSegmentDTO): Promise<ResponseSegmentDTO | undefined> {
        return this.segmentUseCase.updateSegment(id, segment);
    }

    async delete(id: number): Promise<void> {
        return this.segmentUseCase.deleteSegment(id);
    }
}
