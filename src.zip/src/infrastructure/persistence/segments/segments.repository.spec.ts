import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Segments } from '@domain/models/segments.model';
import { SegmentsRepositoryImpl } from './segments.repository';
import { segmentsMock, segmentsArrayMock } from '@mocks/segments.mock';

describe('SegmentsRepository', () => {
    let repository: Repository<Segments>;
    let segmentsRepository: SegmentsRepositoryImpl;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                SegmentsRepositoryImpl,
                {
                    provide: getRepositoryToken(Segments),
                    useClass: Repository,
                },
            ],
        }).compile();

        repository = module.get<Repository<Segments>>(getRepositoryToken(Segments));
        segmentsRepository = module.get<SegmentsRepositoryImpl>(SegmentsRepositoryImpl);
    });

    describe('findAll', () => {
        it('should return an array of segments', async () => {
            const segments: Segments[] = segmentsArrayMock;
            jest.spyOn(repository, 'find').mockResolvedValue(segments);

            const result = await segmentsRepository.findAll();

            expect(result).toEqual(segments);
        });
    });

    describe('findById', () => {
        it('should return a segment by id', async () => {
            const id = 1;
            const segment: Segments = segmentsMock;
            jest.spyOn(repository, 'findOne').mockResolvedValue(segment);

            const result = await segmentsRepository.findById(id);

            expect(result).toEqual(segment);
        });

        it('should return undefined if segment is not found', async () => {
            const id = 1;
            jest.spyOn(repository, 'findOne').mockResolvedValue(undefined);

            const result = await segmentsRepository.findById(id);

            expect(result).toBeUndefined();
        });
    });

    describe('create', () => {
        it('should create a new segment', async () => {
            const segment: Segments = segmentsMock;
            jest.spyOn(repository, 'save').mockResolvedValue(segment);

            const result = await segmentsRepository.create(segment);

            expect(result).toEqual(segment);
        });
    });

    describe('update', () => {
        it('should update a segment by id', async () => {
            const id = 1;
            const segment: Segments = segmentsMock;
            jest.spyOn(repository, 'findOne').mockResolvedValue(segment);
            jest.spyOn(repository, 'save').mockResolvedValue(segment);

            const result = await segmentsRepository.update(id, segment);

            expect(result).toEqual(segment);
        });

        it('should return undefined if segment is not found', async () => {
            const id = 1;
            const segment: Segments = segmentsMock;
            jest.spyOn(repository, 'findOne').mockResolvedValue(undefined);

            const result = await segmentsRepository.update(id, segment);

            expect(result).toBeUndefined();
        });
    });

    describe('delete', () => {
        it('should delete a segment by id', async () => {
            const id = 1;
            jest.spyOn(repository, 'delete').mockResolvedValue(undefined);

            await segmentsRepository.delete(id);

            expect(repository.delete).toHaveBeenCalledWith(id);
        });
    });
});
