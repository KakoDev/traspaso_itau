import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Segments } from '@domain/models/segments.model';
import { SegmentsRepository } from '@domain/repositories/segments.repository.interface';
import { CreateSegmentDTO } from '@interfaces/dtos/segments/create-segments.dtos';
import { UpdateSegmentDTO } from '@interfaces/dtos/segments/update-segments.dtos';

@Injectable()
export class SegmentsRepositoryImpl implements SegmentsRepository {
    constructor( @InjectRepository(Segments) private readonly repository: Repository<Segments>) { }

    async findAll(): Promise<Segments[]> {
        return this.repository.find();
    }

    async findById(id: number): Promise<Segments | undefined> {
        return this.repository.findOne({ where: { id } });
    }

    async create(segment: CreateSegmentDTO): Promise<Segments> {
        return this.repository.save(segment);
    }

    async update(id: number, segment: UpdateSegmentDTO): Promise<Segments | undefined> {
        await this.repository.update(id, segment);
        return this.findById(id);
    }

    async delete(id: number): Promise<void> {
        await this.repository.delete(id);
    }
}