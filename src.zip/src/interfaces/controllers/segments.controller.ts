// interfaces/controllers/segment.controller.ts

import { Body, Controller, Delete, Get, HttpStatus, Param, Post, Put, UseFilters } from '@nestjs/common';
import { ApiNotFoundResponse, ApiOkResponse, ApiTags, ApiUnauthorizedResponse } from '@nestjs/swagger';

import { SegmentsService } from '@app/segments/segments.service';
import { Segments } from '@domain/models/segments.model';
import { CreateSegmentDTO } from '@interfaces/dtos/segments/create-segments.dtos';
import { HttpExceptionFilter } from '@shared/interceptor/http.exception.filter';
import { ResponseSegmentDTO } from '@interfaces/dtos/segments/response-segments.dtos';

@ApiTags('Segments')
@UseFilters(HttpExceptionFilter)
@Controller('segments')
export class SegmentsController {
    constructor(private readonly segmentService: SegmentsService) { }

    @Get()
    @ApiOkResponse({ description: 'Obtener todos los segmentos' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async findAll(): Promise<ResponseSegmentDTO[]> {
        return this.segmentService.findAll();
    }

    @Get(':id')
    @ApiOkResponse({ description: 'Obtener segumento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async findById(@Param('id') id: number): Promise<ResponseSegmentDTO | undefined> {
        return this.segmentService.findById(id);
    }

    @Post()
    @ApiOkResponse({ description: 'Creación de Segmento' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async create(@Body() segment: CreateSegmentDTO): Promise<ResponseSegmentDTO> {
        return this.segmentService.create(segment);
    }

    @Put(':id')
    @ApiOkResponse({ description: 'Actualización de segmento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async update(@Param('id') id: number, @Body() segment: Segments): Promise<ResponseSegmentDTO | undefined> {
        return this.segmentService.update(id, segment);
    }

    @Delete(':id')
    @ApiOkResponse({ description: 'Eliminación de segumento según ID' })
    @ApiUnauthorizedResponse({ status: HttpStatus.UNAUTHORIZED, description: "Operación no autorizada" })
    @ApiNotFoundResponse({ status: HttpStatus.NOT_FOUND, description: 'Operación no encontrada' })
    async delete(@Param('id') id: number): Promise<void> {
        return this.segmentService.delete(id);
    }
}
