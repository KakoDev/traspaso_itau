import { Segments } from "@domain/models/segments.model";

export interface UpdateSegmentDTO {
    segment: string;
    updatedBy: string;
}
