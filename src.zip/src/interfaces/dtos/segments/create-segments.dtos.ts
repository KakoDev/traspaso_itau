export interface CreateSegmentDTO {
    segment: string;
    createdBy: string;
}

export interface UpdateSegmentDTO {
    segment: string;
    updatedBy: string;
}
