export interface ResponseSegmentDTO {
    id: number;
    segment: string;
}
