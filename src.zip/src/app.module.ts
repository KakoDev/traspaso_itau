import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

import { LoggerModule } from '@frameworks/Logger/logger.module';
import { DatabaseModule } from '@infrastructure/adapter/database/database.module';
import { SegmentModule } from '@interfaces/segment.module';
// import { AppService } from './app.service';
// import { HealthModule } from './domain/health/health.module';
// import { ProductModule } from './domain/product/product.module';
// import { InterceptorModule } from './shared/interceptor/interceptor.module';
// import { UtilsModule } from './shared/utils/utils.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    DatabaseModule,
    SegmentModule,
    LoggerModule
    // InterceptorModule,
    // HealthModule,
    // UtilsModule,
    // ProductModule,
  ],
  //providers: [AppService],
})
export class AppModule {}
