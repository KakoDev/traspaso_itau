import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { Curves } from "./Curves";
import { DayCounters } from "./DayCounters";
import { Currencies } from "./Currencies";
import { Frequencies } from "./Frequencies";
import { InterestRateIndexes } from "./InterestRateIndexes";

@Index("xccy_rate_helpers_pkey", ["id"], { unique: true })
@Entity("xccy_rate_helpers", { schema: "ingfin" })
export class XccyRateHelpers {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "tenor", length: 50 })
  tenor: string;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @Column("integer", { name: "settlement_days" })
  settlementDays: number;

  @Column("character varying", { name: "fwd_start", length: 50 })
  fwdStart: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @Column("double precision", {
    name: "rate_value",
    nullable: true,
    precision: 53,
  })
  rateValue: number | null;

  @Column("character varying", {
    name: "rate_ticker",
    nullable: true,
    length: 100,
  })
  rateTicker: string | null;

  @Column("double precision", {
    name: "spread_value",
    nullable: true,
    precision: 53,
  })
  spreadValue: number | null;

  @Column("character varying", {
    name: "spread_ticker",
    nullable: true,
    length: 100,
  })
  spreadTicker: string | null;

  @Column("double precision", {
    name: "fx_spot_value",
    nullable: true,
    precision: 53,
  })
  fxSpotValue: number | null;

  @Column("character varying", {
    name: "fx_spot_ticker",
    nullable: true,
    length: 100,
  })
  fxSpotTicker: string | null;

  @ManyToOne(() => Calendars, (calendars) => calendars.xccyRateHelpers)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(() => Conventions, (conventions) => conventions.xccyRateHelpers)
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(() => Curves, (curves) => curves.xccyRateHelpers)
  @JoinColumn([{ name: "curve_id", referencedColumnName: "id" }])
  curve: Curves;

  @ManyToOne(() => DayCounters, (dayCounters) => dayCounters.xccyRateHelpers)
  @JoinColumn([{ name: "day_counter_id", referencedColumnName: "id" }])
  dayCounter: DayCounters;

  @ManyToOne(() => Curves, (curves) => curves.xccyRateHelpers2)
  @JoinColumn([{ name: "discount_curve_id", referencedColumnName: "id" }])
  discountCurve: Curves;

  @ManyToOne(() => Currencies, (currencies) => currencies.xccyRateHelpers)
  @JoinColumn([{ name: "fixed_leg_currency_id", referencedColumnName: "id" }])
  fixedLegCurrency: Currencies;

  @ManyToOne(() => Frequencies, (frequencies) => frequencies.xccyRateHelpers)
  @JoinColumn([{ name: "fixed_leg_frequency_id", referencedColumnName: "id" }])
  fixedLegFrequency: Frequencies;

  @ManyToOne(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.xccyRateHelpers
  )
  @JoinColumn([{ name: "index_id", referencedColumnName: "id" }])
  index: InterestRateIndexes;
}
