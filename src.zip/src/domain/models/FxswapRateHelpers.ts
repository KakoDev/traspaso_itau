import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { Curves } from "./Curves";

@Index("fxswap_rate_helpers_pkey", ["id"], { unique: true })
@Entity("fxswap_rate_helpers", { schema: "ingfin" })
export class FxswapRateHelpers {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "tenor", nullable: true, length: 50 })
  tenor: string | null;

  @Column("date", { name: "end_date", nullable: true })
  endDate: string | null;

  @Column("integer", { name: "fixing_days" })
  fixingDays: number;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @Column("boolean", { name: "base_currency_as_collateral" })
  baseCurrencyAsCollateral: boolean;

  @Column("integer", { name: "settlement_days" })
  settlementDays: number;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @Column("double precision", {
    name: "fx_spot_value",
    nullable: true,
    precision: 53,
  })
  fxSpotValue: number | null;

  @Column("character varying", {
    name: "fx_spot_ticker",
    nullable: true,
    length: 100,
  })
  fxSpotTicker: string | null;

  @Column("double precision", {
    name: "fx_points_value",
    nullable: true,
    precision: 53,
  })
  fxPointsValue: number | null;

  @Column("character varying", {
    name: "fx_points_ticker",
    nullable: true,
    length: 100,
  })
  fxPointsTicker: string | null;

  @ManyToOne(() => Calendars, (calendars) => calendars.fxswapRateHelpers)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(() => Conventions, (conventions) => conventions.fxswapRateHelpers)
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(() => Curves, (curves) => curves.fxswapRateHelpers)
  @JoinColumn([{ name: "curve_id", referencedColumnName: "id" }])
  curve: Curves;

  @ManyToOne(() => Curves, (curves) => curves.fxswapRateHelpers2)
  @JoinColumn([{ name: "discount_curve_id", referencedColumnName: "id" }])
  discountCurve: Curves;
}
