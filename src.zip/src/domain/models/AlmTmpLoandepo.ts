import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmTmpCashflow } from "./AlmTmpCashflow";

@Index("alm_tmp_loandepo_pkey", ["loandepoId"], { unique: true })
@Entity("alm_tmp_loandepo", { schema: "ingfin" })
export class AlmTmpLoandepo {
  @Column("bigint", { name: "id" })
  id: string;

  @PrimaryGeneratedColumn({ type: "bigint", name: "loandepo_id" })
  loandepoId: string;

  @Column("date", { name: "process_date" })
  processDate: string;

  @Column("character varying", { name: "segment", length: 50 })
  segment: string;

  @Column("character varying", { name: "structure", length: 50 })
  structure: string;

  @Column("character varying", { name: "currency", length: 50 })
  currency: string;

  @Column("character varying", { name: "rate_type", length: 50 })
  rateType: string;

  @Column("double precision", { name: "client_rate", precision: 53 })
  clientRate: number;

  @Column("double precision", { name: "ftp_rate", precision: 53 })
  ftpRate: number;

  @Column("character varying", { name: "product_family", length: 50 })
  productFamily: string;

  @Column("double precision", { name: "notional", precision: 53 })
  notional: number;

  @Column("date", { name: "start_date" })
  startDate: string;

  @Column("date", { name: "end_date" })
  endDate: string;

  @Column("date", { name: "last_fixing_date" })
  lastFixingDate: string;

  @Column("character varying", { name: "forecast_curve_code", length: 50 })
  forecastCurveCode: string;

  @Column("character varying", {
    name: "forecast_curve",
    nullable: true,
    length: 100,
  })
  forecastCurve: string | null;

  @Column("character varying", { name: "discount_curve", length: 100 })
  discountCurve: string;

  @Column("character varying", { name: "payment_frequency", length: 50 })
  paymentFrequency: string;

  @Column("integer", { name: "months_to_first_coupon" })
  monthsToFirstCoupon: number;

  @Column("character varying", { name: "side", length: 50 })
  side: string;

  @Column("character varying", { name: "rate_day_counter", length: 50 })
  rateDayCounter: string;

  @Column("character varying", { name: "rate_compounding", length: 50 })
  rateCompounding: string;

  @Column("character varying", { name: "rate_frequency", length: 50 })
  rateFrequency: string;

  @Column("double precision", { name: "fixing", nullable: true, precision: 53 })
  fixing: number | null;

  @OneToMany(() => AlmTmpCashflow, (almTmpCashflow) => almTmpCashflow.loandepo)
  almTmpCashflows: AlmTmpCashflow[];
}
