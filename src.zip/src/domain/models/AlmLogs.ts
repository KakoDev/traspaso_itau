import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("alm_logs_pkey", ["id"], { unique: true })
@Entity("alm_logs", { schema: "ingfin" })
export class AlmLogs {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("date", { name: "process_date", nullable: true })
  processDate: string | null;

  @Column("integer", { name: "process_id" })
  processId: number;

  @Column("character varying", { name: "process_name", length: 50 })
  processName: string;

  @Column("bigint", { name: "loandepo_id", nullable: true })
  loandepoId: string | null;

  @Column("character varying", { name: "status", length: 50 })
  status: string;

  @Column("character varying", { name: "message", length: 500 })
  message: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;
}
