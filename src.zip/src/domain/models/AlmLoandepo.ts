import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("alm_loandepo_pkey", ["id"], { unique: true })
@Entity("alm_loandepo", { schema: "ingfin" })
export class AlmLoandepo {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("bigint", { name: "mis_id" })
  misId: string;

  @Column("date", { name: "process_date" })
  processDate: string;

  @Column("double precision", { name: "client_rate", precision: 53 })
  clientRate: number;

  @Column("double precision", { name: "ftp_rate", precision: 53 })
  ftpRate: number;

  @Column("double precision", { name: "notional", precision: 53 })
  notional: number;

  @Column("date", { name: "start_date" })
  startDate: string;

  @Column("date", { name: "end_date" })
  endDate: string;

  @Column("date", { name: "last_fixing_date", nullable: true })
  lastFixingDate: string | null;

  @Column("integer", { name: "months_to_first_coupon", nullable: true })
  monthsToFirstCoupon: number | null;

  @ManyToOne(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.almLoandepos
  )
  @JoinColumn([
    { name: "loandepo_configuration_id", referencedColumnName: "id" },
  ])
  loandepoConfiguration: LoandepoConfigurations;
}
