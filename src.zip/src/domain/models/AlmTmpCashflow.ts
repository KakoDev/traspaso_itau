import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmTmpLoandepo } from "./AlmTmpLoandepo";

@Index("alm_tmp_cashflow_pkey", ["id"], { unique: true })
@Entity("alm_tmp_cashflow", { schema: "ingfin" })
export class AlmTmpCashflow {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("date", { name: "process_date" })
  processDate: string;

  @Column("date", { name: "payment_date" })
  paymentDate: string;

  @Column("double precision", { name: "redemption", precision: 53 })
  redemption: number;

  @ManyToOne(
    () => AlmTmpLoandepo,
    (almTmpLoandepo) => almTmpLoandepo.almTmpCashflows,
    { onDelete: "CASCADE" }
  )
  @JoinColumn([{ name: "loandepo_id", referencedColumnName: "loandepoId" }])
  loandepo: AlmTmpLoandepo;
}
