import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmRolloverSimulation } from "./AlmRolloverSimulation";

@Index("alm_rollover_strategy_pkey", ["id"], { unique: true })
@Entity("alm_rollover_strategy", { schema: "ingfin" })
export class AlmRolloverStrategy {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("character varying", { name: "strategy", length: 255 })
  strategy: string;

  @Column("character varying", { name: "description", length: 255 })
  description: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @ManyToOne(
    () => AlmRolloverSimulation,
    (almRolloverSimulation) => almRolloverSimulation.almRolloverStrategies
  )
  @JoinColumn([{ name: "simulation_id", referencedColumnName: "id" }])
  simulation: AlmRolloverSimulation;
}
