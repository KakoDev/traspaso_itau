import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { BondRateHelpers } from "./BondRateHelpers";
import { LoandepoConfigurations } from "./LoandepoConfigurations";
import { OisRateHelpers } from "./OisRateHelpers";
import { SwapRateHelpers } from "./SwapRateHelpers";
import { XccyRateHelpers } from "./XccyRateHelpers";

@Index("frequencies_frequency_key", ["frequency"], { unique: true })
@Index("frequencies_pkey", ["id"], { unique: true })
@Entity("frequencies", { schema: "ingfin" })
export class Frequencies {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "frequency", unique: true, length: 50 })
  frequency: string;

  @OneToMany(
    () => BondRateHelpers,
    (bondRateHelpers) => bondRateHelpers.frequency
  )
  bondRateHelpers: BondRateHelpers[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.firstRateFrequency
  )
  loandepoConfigurations: LoandepoConfigurations[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.paymentFrequency
  )
  loandepoConfigurations2: LoandepoConfigurations[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.secondRateFrequency
  )
  loandepoConfigurations3: LoandepoConfigurations[];

  @OneToMany(
    () => OisRateHelpers,
    (oisRateHelpers) => oisRateHelpers.fixedLegFrequency
  )
  oisRateHelpers: OisRateHelpers[];

  @OneToMany(() => OisRateHelpers, (oisRateHelpers) => oisRateHelpers.frequency)
  oisRateHelpers2: OisRateHelpers[];

  @OneToMany(
    () => SwapRateHelpers,
    (swapRateHelpers) => swapRateHelpers.fixedLegFrequency
  )
  swapRateHelpers: SwapRateHelpers[];

  @OneToMany(
    () => SwapRateHelpers,
    (swapRateHelpers) => swapRateHelpers.frequency
  )
  swapRateHelpers2: SwapRateHelpers[];

  @OneToMany(
    () => XccyRateHelpers,
    (xccyRateHelpers) => xccyRateHelpers.fixedLegFrequency
  )
  xccyRateHelpers: XccyRateHelpers[];
}
