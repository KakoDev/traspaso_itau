import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmCashflows } from "./AlmCashflows";
import { Currencies } from "./Currencies";
import { CurveTypes } from "./CurveTypes";
import { DayCounters } from "./DayCounters";
import { InterestRateIndexes } from "./InterestRateIndexes";
import { Curves } from "./Curves";
import { LoanQuoteCashflows } from "./LoanQuoteCashflows";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("curve_descriptions_name_curve_type_id_key", ["curveTypeId", "name"], {
  unique: true,
})
@Index("curve_descriptions_pkey", ["id"], { unique: true })
@Entity("curve_descriptions", { schema: "ingfin" })
export class CurveDescriptions {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "name", unique: true, length: 100 })
  name: string;

  @Column("character varying", {
    name: "description",
    nullable: true,
    length: 255,
  })
  description: string | null;

  @Column("integer", { name: "curve_type_id", unique: true })
  curveTypeId: number;

  @Column("boolean", { name: "enable_extrapolation" })
  enableExtrapolation: boolean;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @OneToMany(() => AlmCashflows, (almCashflows) => almCashflows.forecastCurve)
  almCashflows: AlmCashflows[];

  @ManyToOne(() => Currencies, (currencies) => currencies.curveDescriptions)
  @JoinColumn([{ name: "currency_id", referencedColumnName: "id" }])
  currency: Currencies;

  @ManyToOne(() => CurveTypes, (curveTypes) => curveTypes.curveDescriptions)
  @JoinColumn([{ name: "curve_type_id", referencedColumnName: "id" }])
  curveType: CurveTypes;

  @ManyToOne(() => DayCounters, (dayCounters) => dayCounters.curveDescriptions)
  @JoinColumn([{ name: "day_counter_id", referencedColumnName: "id" }])
  dayCounter: DayCounters;

  @ManyToOne(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.curveDescriptions
  )
  @JoinColumn([{ name: "interest_rate_index_id", referencedColumnName: "id" }])
  interestRateIndex: InterestRateIndexes;

  @OneToMany(() => Curves, (curves) => curves.curveDescription)
  curves: Curves[];

  @OneToMany(
    () => LoanQuoteCashflows,
    (loanQuoteCashflows) => loanQuoteCashflows.forecastCurve
  )
  loanQuoteCashflows: LoanQuoteCashflows[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.discountCurve
  )
  loandepoConfigurations: LoandepoConfigurations[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.forecastCurve
  )
  loandepoConfigurations2: LoandepoConfigurations[];
}
