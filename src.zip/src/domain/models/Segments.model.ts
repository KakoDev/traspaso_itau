import {
  Column,
  Entity,
  Index,
  PrimaryGeneratedColumn
} from "typeorm";

@Index("segments_pkey1", ["id"], { unique: true })
@Index("segments_segments_key1", ["segment"], { unique: true })
@Entity("segments", { schema: "ingfin" })
export class Segments {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "segment", unique: true, length: 50 })
  segment: string;

  @Column("character varying", {
    name: "created_by",
    nullable: true,
    length: 50,
  })
  createdBy: string | null;

  @Column("timestamp without time zone", { name: "created_at", default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @Column("timestamp without time zone", { name: "updated_at", nullable: true })
  updatedAt: Date | null;
}