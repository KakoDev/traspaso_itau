import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { Curves } from "./Curves";
import { DayCounters } from "./DayCounters";
import { Frequencies } from "./Frequencies";
import { InterestRateIndexes } from "./InterestRateIndexes";

@Index("swap_rate_helpers_pkey", ["id"], { unique: true })
@Entity("swap_rate_helpers", { schema: "ingfin" })
export class SwapRateHelpers {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "tenor", length: 50 })
  tenor: string;

  @Column("integer", { name: "settlement_days" })
  settlementDays: number;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @Column("character varying", { name: "fwd_start", length: 50 })
  fwdStart: string;

  @Column("double precision", {
    name: "rate_value",
    nullable: true,
    precision: 53,
  })
  rateValue: number | null;

  @Column("character varying", {
    name: "rate_ticker",
    nullable: true,
    length: 100,
  })
  rateTicker: string | null;

  @Column("double precision", {
    name: "spread_value",
    nullable: true,
    precision: 53,
  })
  spreadValue: number | null;

  @Column("character varying", {
    name: "spread_ticker",
    nullable: true,
    length: 100,
  })
  spreadTicker: string | null;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @ManyToOne(() => Calendars, (calendars) => calendars.swapRateHelpers)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(() => Conventions, (conventions) => conventions.swapRateHelpers)
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(() => Curves, (curves) => curves.swapRateHelpers)
  @JoinColumn([{ name: "curve_id", referencedColumnName: "id" }])
  curve: Curves;

  @ManyToOne(() => DayCounters, (dayCounters) => dayCounters.swapRateHelpers)
  @JoinColumn([{ name: "day_counter_id", referencedColumnName: "id" }])
  dayCounter: DayCounters;

  @ManyToOne(() => Curves, (curves) => curves.swapRateHelpers2)
  @JoinColumn([{ name: "discount_curve_id", referencedColumnName: "id" }])
  discountCurve: Curves;

  @ManyToOne(() => Frequencies, (frequencies) => frequencies.swapRateHelpers)
  @JoinColumn([{ name: "fixed_leg_frequency_id", referencedColumnName: "id" }])
  fixedLegFrequency: Frequencies;

  @ManyToOne(() => Frequencies, (frequencies) => frequencies.swapRateHelpers2)
  @JoinColumn([{ name: "frequency_id", referencedColumnName: "id" }])
  frequency: Frequencies;

  @ManyToOne(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.swapRateHelpers
  )
  @JoinColumn([{ name: "index_id", referencedColumnName: "id" }])
  index: InterestRateIndexes;
}
