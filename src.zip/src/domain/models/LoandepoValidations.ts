import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("loandepo_validations_pkey", ["id"], { unique: true })
@Entity("loandepo_validations", { schema: "ingfin" })
export class LoandepoValidations {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "min_tenor", length: 50 })
  minTenor: string;

  @Column("character varying", { name: "max_tenor", length: 50 })
  maxTenor: string;

  @Column("double precision", { name: "min_notional", precision: 53 })
  minNotional: number;

  @Column("double precision", { name: "max_notional", precision: 53 })
  maxNotional: number;
}
