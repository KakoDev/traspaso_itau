import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { BondRateHelpers } from "./BondRateHelpers";
import { DepositRateHelpers } from "./DepositRateHelpers";
import { FxswapRateHelpers } from "./FxswapRateHelpers";
import { InterestRateIndexes } from "./InterestRateIndexes";
import { LoandepoConfigurations } from "./LoandepoConfigurations";
import { OisRateHelpers } from "./OisRateHelpers";
import { SwapRateHelpers } from "./SwapRateHelpers";
import { XccyRateHelpers } from "./XccyRateHelpers";

@Index("calendars_calendar_key", ["calendar"], { unique: true })
@Index("calendars_pkey", ["id"], { unique: true })
@Entity("calendars", { schema: "ingfin" })
export class Calendars {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "calendar", unique: true, length: 50 })
  calendar: string;

  @OneToMany(
    () => BondRateHelpers,
    (bondRateHelpers) => bondRateHelpers.calendar
  )
  bondRateHelpers: BondRateHelpers[];

  @OneToMany(
    () => DepositRateHelpers,
    (depositRateHelpers) => depositRateHelpers.calendar
  )
  depositRateHelpers: DepositRateHelpers[];

  @OneToMany(
    () => FxswapRateHelpers,
    (fxswapRateHelpers) => fxswapRateHelpers.calendar
  )
  fxswapRateHelpers: FxswapRateHelpers[];

  @OneToMany(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.calendar
  )
  interestRateIndexes: InterestRateIndexes[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.calendar
  )
  loandepoConfigurations: LoandepoConfigurations[];

  @OneToMany(() => OisRateHelpers, (oisRateHelpers) => oisRateHelpers.calendar)
  oisRateHelpers: OisRateHelpers[];

  @OneToMany(
    () => SwapRateHelpers,
    (swapRateHelpers) => swapRateHelpers.calendar
  )
  swapRateHelpers: SwapRateHelpers[];

  @OneToMany(
    () => XccyRateHelpers,
    (xccyRateHelpers) => xccyRateHelpers.calendar
  )
  xccyRateHelpers: XccyRateHelpers[];
}
