import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("alm_raw_cashflows_pkey", ["id"], { unique: true })
@Entity("alm_raw_cashflows", { schema: "ingfin" })
export class AlmRawCashflows {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("date", { name: "fec_data" })
  fecData: string;

  @Column("character varying", { name: "contrato_mis", length: 255 })
  contratoMis: string;

  @Column("bigint", { name: "operacion" })
  operacion: string;

  @Column("character varying", { name: "familia_producto", length: 255 })
  familiaProducto: string;

  @Column("character varying", { name: "cod_producto", length: 50 })
  codProducto: string;

  @Column("character varying", { name: "cod_subproducto", length: 50 })
  codSubproducto: string;

  @Column("date", { name: "fec_flujo", nullable: true })
  fecFlujo: string | null;

  @Column("double precision", { name: "capital_ml", precision: 53 })
  capitalMl: number;

  @Column("double precision", { name: "interes_ml", precision: 53 })
  interesMl: number;

  @Column("double precision", { name: "cuota_ml", precision: 53 })
  cuotaMl: number;
}
