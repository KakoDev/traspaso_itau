import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Curves } from "./Curves";

@Index("curve_sets_pkey", ["id"], { unique: true })
@Entity("curve_sets", { schema: "ingfin" })
export class CurveSets {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("date", { name: "reference_date" })
  referenceDate: string;

  @Column("character varying", { name: "name", length: 100 })
  name: string;

  @Column("character varying", {
    name: "description",
    nullable: true,
    length: 255,
  })
  description: string | null;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @OneToMany(() => Curves, (curves) => curves.curveSet)
  curves: Curves[];
}
