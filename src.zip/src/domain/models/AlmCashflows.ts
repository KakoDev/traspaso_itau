import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { CashflowTypes } from "./CashflowTypes";
import { Currencies } from "./Currencies";
import { CurveDescriptions } from "./CurveDescriptions";
import { Sides } from "./Sides";

@Index("alm_cashflows_pkey", ["id"], { unique: true })
@Entity("alm_cashflows", { schema: "ingfin" })
export class AlmCashflows {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("bigint", { name: "mis_id" })
  misId: string;

  @Column("date", { name: "accrual_start_date", nullable: true })
  accrualStartDate: string | null;

  @Column("date", { name: "accrual_end_date", nullable: true })
  accrualEndDate: string | null;

  @Column("date", { name: "payment_date" })
  paymentDate: string;

  @Column("double precision", {
    name: "notional",
    nullable: true,
    precision: 53,
  })
  notional: number | null;

  @Column("double precision", { name: "amount", nullable: true, precision: 53 })
  amount: number | null;

  @Column("character varying", { name: "source", nullable: true, length: 3 })
  source: string | null;

  @ManyToOne(() => CashflowTypes, (cashflowTypes) => cashflowTypes.almCashflows)
  @JoinColumn([{ name: "cashflow_type_id", referencedColumnName: "id" }])
  cashflowType: CashflowTypes;

  @ManyToOne(() => Currencies, (currencies) => currencies.almCashflows)
  @JoinColumn([{ name: "currency_id", referencedColumnName: "id" }])
  currency: Currencies;

  @ManyToOne(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.almCashflows
  )
  @JoinColumn([{ name: "forecast_curve_id", referencedColumnName: "id" }])
  forecastCurve: CurveDescriptions;

  @ManyToOne(() => Sides, (sides) => sides.almCashflows)
  @JoinColumn([{ name: "side_id", referencedColumnName: "id" }])
  side: Sides;
}
