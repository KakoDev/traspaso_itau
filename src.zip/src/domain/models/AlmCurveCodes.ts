import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("alm_curve_codes_pkey", ["id"], { unique: true })
@Entity("alm_curve_codes", { schema: "ingfin" })
export class AlmCurveCodes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "code", length: 50 })
  code: string;

  @Column("character varying", { name: "curve_name", length: 50 })
  curveName: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;
}
