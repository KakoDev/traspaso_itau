import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { Curves } from "./Curves";
import { DayCounters } from "./DayCounters";
import { Frequencies } from "./Frequencies";
import { InterestRateIndexes } from "./InterestRateIndexes";

@Index("ois_rate_helpers_pkey", ["id"], { unique: true })
@Entity("ois_rate_helpers", { schema: "ingfin" })
export class OisRateHelpers {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "tenor", length: 50 })
  tenor: string;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @Column("integer", { name: "settlement_days" })
  settlementDays: number;

  @Column("integer", { name: "payment_lag" })
  paymentLag: number;

  @Column("boolean", { name: "telescopic_value_dates" })
  telescopicValueDates: boolean;

  @Column("character varying", { name: "fwd_start", length: 50 })
  fwdStart: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @Column("double precision", {
    name: "rate_value",
    nullable: true,
    precision: 53,
  })
  rateValue: number | null;

  @Column("character varying", {
    name: "rate_ticker",
    nullable: true,
    length: 100,
  })
  rateTicker: string | null;

  @Column("double precision", {
    name: "spread_value",
    nullable: true,
    precision: 53,
  })
  spreadValue: number | null;

  @Column("character varying", {
    name: "spread_ticker",
    nullable: true,
    length: 100,
  })
  spreadTicker: string | null;

  @ManyToOne(() => Calendars, (calendars) => calendars.oisRateHelpers)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(() => Conventions, (conventions) => conventions.oisRateHelpers)
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(() => Curves, (curves) => curves.oisRateHelpers)
  @JoinColumn([{ name: "curve_id", referencedColumnName: "id" }])
  curve: Curves;

  @ManyToOne(() => DayCounters, (dayCounters) => dayCounters.oisRateHelpers)
  @JoinColumn([{ name: "day_counter_id", referencedColumnName: "id" }])
  dayCounter: DayCounters;

  @ManyToOne(() => Curves, (curves) => curves.oisRateHelpers2)
  @JoinColumn([{ name: "discount_curve_id", referencedColumnName: "id" }])
  discountCurve: Curves;

  @ManyToOne(() => Frequencies, (frequencies) => frequencies.oisRateHelpers)
  @JoinColumn([{ name: "fixed_leg_frequency_id", referencedColumnName: "id" }])
  fixedLegFrequency: Frequencies;

  @ManyToOne(() => Frequencies, (frequencies) => frequencies.oisRateHelpers2)
  @JoinColumn([{ name: "frequency_id", referencedColumnName: "id" }])
  frequency: Frequencies;

  @ManyToOne(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.oisRateHelpers
  )
  @JoinColumn([{ name: "index_id", referencedColumnName: "id" }])
  index: InterestRateIndexes;
}
