import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { BondRateHelpers } from "./BondRateHelpers";
import { CurveDescriptions } from "./CurveDescriptions";
import { DepositRateHelpers } from "./DepositRateHelpers";
import { InterestRateIndexes } from "./InterestRateIndexes";
import { LoandepoConfigurations } from "./LoandepoConfigurations";
import { OisRateHelpers } from "./OisRateHelpers";
import { SwapRateHelpers } from "./SwapRateHelpers";
import { XccyRateHelpers } from "./XccyRateHelpers";

@Index("day_counters_day_counter_key", ["dayCounter"], { unique: true })
@Index("day_counters_pkey", ["id"], { unique: true })
@Entity("day_counters", { schema: "ingfin" })
export class DayCounters {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "day_counter",
    unique: true,
    length: 50,
  })
  dayCounter: string;

  @OneToMany(
    () => BondRateHelpers,
    (bondRateHelpers) => bondRateHelpers.couponDayCounter
  )
  bondRateHelpers: BondRateHelpers[];

  @OneToMany(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.dayCounter
  )
  curveDescriptions: CurveDescriptions[];

  @OneToMany(
    () => DepositRateHelpers,
    (depositRateHelpers) => depositRateHelpers.dayCounter
  )
  depositRateHelpers: DepositRateHelpers[];

  @OneToMany(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.dayCounter
  )
  interestRateIndexes: InterestRateIndexes[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.firstRateDayCounter
  )
  loandepoConfigurations: LoandepoConfigurations[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.secondRateDayCounter
  )
  loandepoConfigurations2: LoandepoConfigurations[];

  @OneToMany(
    () => OisRateHelpers,
    (oisRateHelpers) => oisRateHelpers.dayCounter
  )
  oisRateHelpers: OisRateHelpers[];

  @OneToMany(
    () => SwapRateHelpers,
    (swapRateHelpers) => swapRateHelpers.dayCounter
  )
  swapRateHelpers: SwapRateHelpers[];

  @OneToMany(
    () => XccyRateHelpers,
    (xccyRateHelpers) => xccyRateHelpers.dayCounter
  )
  xccyRateHelpers: XccyRateHelpers[];
}
