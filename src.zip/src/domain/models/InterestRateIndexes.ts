import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { CurveDescriptions } from "./CurveDescriptions";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { Currencies } from "./Currencies";
import { DayCounters } from "./DayCounters";
import { IndexTypes } from "./IndexTypes";
import { OisRateHelpers } from "./OisRateHelpers";
import { SwapRateHelpers } from "./SwapRateHelpers";
import { XccyRateHelpers } from "./XccyRateHelpers";

@Index("interest_rate_indexes_pkey", ["id"], { unique: true })
@Entity("interest_rate_indexes", { schema: "ingfin" })
export class InterestRateIndexes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "name", length: 100 })
  name: string;

  @Column("character varying", { name: "tenor", length: 50 })
  tenor: string;

  @Column("integer", { name: "fixing_days" })
  fixingDays: number;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @Column("character varying", {
    name: "fixing_ticker",
    nullable: true,
    length: 100,
  })
  fixingTicker: string | null;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @OneToMany(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.interestRateIndex
  )
  curveDescriptions: CurveDescriptions[];

  @ManyToOne(() => Calendars, (calendars) => calendars.interestRateIndexes)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(
    () => Conventions,
    (conventions) => conventions.interestRateIndexes
  )
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(() => Currencies, (currencies) => currencies.interestRateIndexes)
  @JoinColumn([{ name: "currency_id", referencedColumnName: "id" }])
  currency: Currencies;

  @ManyToOne(
    () => DayCounters,
    (dayCounters) => dayCounters.interestRateIndexes
  )
  @JoinColumn([{ name: "day_counter_id", referencedColumnName: "id" }])
  dayCounter: DayCounters;

  @ManyToOne(() => IndexTypes, (indexTypes) => indexTypes.interestRateIndexes)
  @JoinColumn([{ name: "index_type_id", referencedColumnName: "id" }])
  indexType: IndexTypes;

  @OneToMany(() => OisRateHelpers, (oisRateHelpers) => oisRateHelpers.index)
  oisRateHelpers: OisRateHelpers[];

  @OneToMany(() => SwapRateHelpers, (swapRateHelpers) => swapRateHelpers.index)
  swapRateHelpers: SwapRateHelpers[];

  @OneToMany(() => XccyRateHelpers, (xccyRateHelpers) => xccyRateHelpers.index)
  xccyRateHelpers: XccyRateHelpers[];
}
