import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("rate_types_pkey", ["id"], { unique: true })
@Index("rate_types_rate_type_key", ["rateType"], { unique: true })
@Entity("rate_types", { schema: "ingfin" })
export class RateTypes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "rate_type", unique: true, length: 50 })
  rateType: string;

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.rateType
  )
  loandepoConfigurations: LoandepoConfigurations[];
}
