import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { Curves } from "./Curves";
import { DayCounters } from "./DayCounters";

@Index("deposit_rate_helpers_pkey", ["id"], { unique: true })
@Entity("deposit_rate_helpers", { schema: "ingfin" })
export class DepositRateHelpers {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "tenor", length: 50 })
  tenor: string;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @Column("integer", { name: "settlement_days" })
  settlementDays: number;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @Column("double precision", {
    name: "rate_value",
    nullable: true,
    precision: 53,
  })
  rateValue: number | null;

  @Column("character varying", {
    name: "rate_ticker",
    nullable: true,
    length: 100,
  })
  rateTicker: string | null;

  @ManyToOne(() => Calendars, (calendars) => calendars.depositRateHelpers)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(() => Conventions, (conventions) => conventions.depositRateHelpers)
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(() => Curves, (curves) => curves.depositRateHelpers)
  @JoinColumn([{ name: "curve_id", referencedColumnName: "id" }])
  curve: Curves;

  @ManyToOne(() => DayCounters, (dayCounters) => dayCounters.depositRateHelpers)
  @JoinColumn([{ name: "day_counter_id", referencedColumnName: "id" }])
  dayCounter: DayCounters;
}
