import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmCashflows } from "./AlmCashflows";
import { LoanQuoteCashflows } from "./LoanQuoteCashflows";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("sides_pkey", ["id"], { unique: true })
@Index("sides_side_key", ["side"], { unique: true })
@Entity("sides", { schema: "ingfin" })
export class Sides {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "side", unique: true, length: 50 })
  side: string;

  @OneToMany(() => AlmCashflows, (almCashflows) => almCashflows.side)
  almCashflows: AlmCashflows[];

  @OneToMany(
    () => LoanQuoteCashflows,
    (loanQuoteCashflows) => loanQuoteCashflows.side
  )
  loanQuoteCashflows: LoanQuoteCashflows[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.side
  )
  loandepoConfigurations: LoandepoConfigurations[];
}
