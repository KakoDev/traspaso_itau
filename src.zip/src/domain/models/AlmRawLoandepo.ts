import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("alm_raw_loandepo_pkey", ["id"], { unique: true })
@Entity("alm_raw_loandepo", { schema: "ingfin" })
export class AlmRawLoandepo {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("date", { name: "fec_data" })
  fecData: string;

  @Column("character varying", { name: "cod_entidad", length: 50 })
  codEntidad: string;

  @Column("character varying", { name: "fuente_origen", length: 50 })
  fuenteOrigen: string;

  @Column("character varying", { name: "estado_crediticio", length: 255 })
  estadoCrediticio: string;

  @Column("character varying", { name: "contrato_mis", length: 255 })
  contratoMis: string;

  @Column("bigint", { name: "operacion" })
  operacion: string;

  @Column("character varying", { name: "segmento", length: 255 })
  segmento: string;

  @Column("character varying", { name: "area_negocio", length: 255 })
  areaNegocio: string;

  @Column("character varying", { name: "banca", length: 255 })
  banca: string;

  @Column("character varying", { name: "cod_producto", length: 50 })
  codProducto: string;

  @Column("character varying", { name: "cod_subproducto", length: 50 })
  codSubproducto: string;

  @Column("character varying", { name: "familia_producto", length: 255 })
  familiaProducto: string;

  @Column("character varying", { name: "tipo_amortizacion", length: 255 })
  tipoAmortizacion: string;

  @Column("character varying", { name: "divisa", length: 50 })
  divisa: string;

  @Column("character varying", { name: "tipo_tasa", length: 50 })
  tipoTasa: string;

  @Column("character varying", {
    name: "cod_curva_referencia",
    nullable: true,
    length: 50,
  })
  codCurvaReferencia: string | null;

  @Column("date", { name: "fec_prx_reprecio", nullable: true })
  fecPrxReprecio: string | null;

  @Column("date", { name: "fec_alta_cto" })
  fecAltaCto: string;

  @Column("date", { name: "fec_ven" })
  fecVen: string;

  @Column("date", { name: "fec_ult_reprecio", nullable: true })
  fecUltReprecio: string | null;

  @Column("character varying", { name: "base_calculo", length: 50 })
  baseCalculo: string;

  @Column("integer", { name: "anos_primer_per_hipo", nullable: true })
  anosPrimerPerHipo: number | null;

  @Column("character varying", { name: "ind_activo_pasivo", length: 50 })
  indActivoPasivo: string;

  @Column("integer", { name: "meses_gracia", nullable: true })
  mesesGracia: number | null;

  @Column("integer", { name: "fre_pago_int", nullable: true })
  frePagoInt: number | null;

  @Column("character varying", { name: "cod_uni_fre_pago_int", length: 50 })
  codUniFrePagoInt: string;

  @Column("character varying", { name: "cod_sit_devengo", length: 50 })
  codSitDevengo: string;

  @Column("integer", { name: "contrato_mis_origen", nullable: true })
  contratoMisOrigen: number | null;

  @Column("integer", { name: "operacion_origen", nullable: true })
  operacionOrigen: number | null;

  @Column("double precision", { name: "tas_int", precision: 53 })
  tasInt: number;

  @Column("double precision", { name: "tasa_cf", precision: 53 })
  tasaCf: number;

  @Column("double precision", { name: "capital_original_mo", precision: 53 })
  capitalOriginalMo: number;

  @Column("double precision", { name: "capital_original_ml", precision: 53 })
  capitalOriginalMl: number;

  @Column("double precision", { name: "capital_mo", precision: 53 })
  capitalMo: number;

  @Column("double precision", { name: "capital_ml", precision: 53 })
  capitalMl: number;

  @Column("double precision", { name: "reajuste_ml", precision: 53 })
  reajusteMl: number;

  @Column("double precision", { name: "interes_mo", precision: 53 })
  interesMo: number;

  @Column("double precision", { name: "interes_ml", precision: 53 })
  interesMl: number;

  @Column("double precision", { name: "capital_promedio_mo", precision: 53 })
  capitalPromedioMo: number;

  @Column("double precision", { name: "capital_promedio_ml", precision: 53 })
  capitalPromedioMl: number;

  @Column("double precision", { name: "reajuste_promedio_ml", precision: 53 })
  reajustePromedioMl: number;

  @Column("double precision", { name: "interes_promedio_mo", precision: 53 })
  interesPromedioMo: number;

  @Column("double precision", { name: "interes_promedio_ml", precision: 53 })
  interesPromedioMl: number;

  @Column("double precision", { name: "costo_fondo_mo", precision: 53 })
  costoFondoMo: number;

  @Column("double precision", { name: "costo_fondo_ml", precision: 53 })
  costoFondoMl: number;

  @Column("double precision", { name: "interes_ganado_mo", precision: 53 })
  interesGanadoMo: number;

  @Column("double precision", { name: "interes_ganado_ml", precision: 53 })
  interesGanadoMl: number;

  @Column("double precision", { name: "margen_efectivo_mo", precision: 53 })
  margenEfectivoMo: number;

  @Column("double precision", { name: "margen_efectivo_ml", precision: 53 })
  margenEfectivoMl: number;

  @Column("integer", { name: "dias", nullable: true })
  dias: number | null;
}
