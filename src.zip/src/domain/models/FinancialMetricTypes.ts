import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { BbgDataDescriptions } from "./BbgDataDescriptions";

@Index(
  "financial_metric_types_financial_metric_type_key",
  ["financialMetricType"],
  { unique: true }
)
@Index("financial_metric_types_pkey", ["id"], { unique: true })
@Entity("financial_metric_types", { schema: "ingfin" })
export class FinancialMetricTypes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "financial_metric_type",
    unique: true,
    length: 50,
  })
  financialMetricType: string;

  @OneToMany(
    () => BbgDataDescriptions,
    (bbgDataDescriptions) => bbgDataDescriptions.financialMetricType
  )
  bbgDataDescriptions: BbgDataDescriptions[];
}
