import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { FinancialMetricTypes } from "./FinancialMetricTypes";

@Index("bbg_data_descriptions_pkey", ["id"], { unique: true })
@Index("bbg_data_descriptions_ticker_key", ["ticker"], { unique: true })
@Entity("bbg_data_descriptions", { schema: "ingfin" })
export class BbgDataDescriptions {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "ticker", unique: true, length: 50 })
  ticker: string;

  @Column("character varying", { name: "description", length: 50 })
  description: string;

  @ManyToOne(
    () => FinancialMetricTypes,
    (financialMetricTypes) => financialMetricTypes.bbgDataDescriptions
  )
  @JoinColumn([{ name: "financial_metric_type", referencedColumnName: "id" }])
  financialMetricType: FinancialMetricTypes;
}
