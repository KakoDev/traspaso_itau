import { CreateSegmentDTO } from '@interfaces/dtos/segments/create-segments.dtos';
import { UpdateSegmentDTO } from '@interfaces/dtos/segments/update-segments.dtos';
import { Segments } from '../models/segments.model';
import { ResponseSegmentDTO } from '@interfaces/dtos/segments/response-segments.dtos';

export interface SegmentsRepository {
    findAll(): Promise<Segments[]>;
    findById(id: number): Promise<ResponseSegmentDTO | undefined>;
    create(segment: CreateSegmentDTO): Promise<ResponseSegmentDTO>;
    update(id: number, segment: UpdateSegmentDTO): Promise<ResponseSegmentDTO | undefined>;
    delete(id: number): Promise<void>;
}