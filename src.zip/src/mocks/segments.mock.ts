import { Segments } from '@domain/models/segments.model';

export const segmentsMock: Segments = {
    id: 1,
    segment: 'Mock Segment',
    createdBy: 'Mock User',
    createdAt: new Date(),
    updatedBy: 'Mock User',
    updatedAt: new Date(),
};

export const segmentsArrayMock: Segments[] = [
    {
        id: 1,
        segment: 'Mock Segment 1',
        createdBy: 'Mock User',
        createdAt: new Date(),
        updatedBy: 'Mock User',
        updatedAt: new Date(),
    },
    {
        id: 2,
        segment: 'Mock Segment 2',
        createdBy: 'Mock User',
        createdAt: new Date(),
        updatedBy: 'Mock User',
        updatedAt: new Date(),
    },
];
