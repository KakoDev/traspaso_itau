import { Module } from '@nestjs/common';
import { DatabaseProvider } from './database.config';

@Module({
    imports: [DatabaseProvider],
})
export class DatabaseModule { }
